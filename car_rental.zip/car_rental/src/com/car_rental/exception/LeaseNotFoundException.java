package com.car_rental.exception;

public class LeaseNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public LeaseNotFoundException() {
		// TODO Auto-generated constructor stub
	}

	public LeaseNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
