package com.car_rental.exception;

public class VehicleNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public VehicleNotFoundException() {
		// TODO Auto-generated constructor stub
	}

	public VehicleNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
