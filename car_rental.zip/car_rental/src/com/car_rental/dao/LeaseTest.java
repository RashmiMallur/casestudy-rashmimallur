package com.car_rental.dao;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.sql.Date;
import java.sql.SQLException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.car_rental.entity.Customers;
import com.car_rental.entity.Lease;
import com.car_rental.entity.Vehicle;
import com.car_rental.exception.LeaseNotFoundException;

public class LeaseTest {
	private ILeaseDAO leasedao;

	@Before
	public void setUp() throws Exception {
		leasedao = new LeaseDAOImpl();
	}

	@After
	public void tearDown() throws Exception {
		leasedao = null;
	}
	
	@Test
	public final void testLeaseCreation() {
		int result = 0;
		Lease lease = null;
		Date startdate = Date.valueOf("2023-12-31");
		Date enddate = Date.valueOf("2024-02-01");
		Customers customer = new Customers();
		customer.setCustomerid(3);
		Vehicle vehicle = new Vehicle();
		vehicle.setVehicleid(2);
		lease = new Lease(startdate.toLocalDate(), enddate.toLocalDate(), customer, vehicle, "monthly");
		try {
			result = leasedao.addLease(lease);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			se.printStackTrace();
			System.out.println("Either url, username or password is wrong or duplicate record");
		}
		assertTrue(result == 1);
	}

	@Test
	public final void testLeaseRetrieve() {
		int leaseid=1;
		Lease lease = null;

		try {
			lease = leasedao.viewLease(leaseid);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
			se.printStackTrace();
		} catch (LeaseNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}
		assertTrue(lease != null);
	}

	@Test
	public final void testLeaseException() {
		Lease lease = null;
		int leaseid = 0;

		try {
			lease = leasedao.viewLease(leaseid);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (LeaseNotFoundException lnfe) {
			System.out.println(lnfe.getMessage());
		}
		assertTrue(lease == null);
	}

}
