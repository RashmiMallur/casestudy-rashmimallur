package com.car_rental.dao;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.sql.SQLException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.car_rental.entity.Vehicle;
import com.car_rental.exception.VehicleNotFoundException;

public class CarTest {
	private IVehicleDAO vehicledao;

	@Before
	public void setUp() throws Exception {
		vehicledao = new VehicleDAOImpl();
	}

	@After
	public void tearDown() throws Exception {
		vehicledao = null;
	}

	@Test
	public final void testVehicleCreation() {
		int result = 0;
		Vehicle vehicle = null;
		vehicle = new Vehicle("Audi", "A6", 2018, 5000, "notavailable", 6, 800);
		try {
			result = vehicledao.addVehicle(vehicle);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
			se.printStackTrace();
		}
		assertTrue(result == 1);
	}
	
	@Test
	public final void testCarException() {
		Vehicle vehicle = null;
		int vehicleid = 5;

		try {
			vehicle = vehicledao.viewVehicle(vehicleid);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (VehicleNotFoundException vnfe) {
			System.out.println(vnfe.getMessage());
		}

		assertTrue(vehicle == null);
	}

}
