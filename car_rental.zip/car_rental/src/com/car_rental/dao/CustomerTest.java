package com.car_rental.dao;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.sql.SQLException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.car_rental.entity.Customers;
import com.car_rental.exception.CustomerNotFoundException;

public class CustomerTest {
	private ICustomerDAO customerdao;

	@Before
	public void setUp() throws Exception {
		customerdao = new CustomerDAOImpl();
	}

	@After
	public void tearDown() throws Exception {
		customerdao = null;
	}

	@Test
	public final void testCustException() {
		Customers customer = null;
		int customerid = 6;

		try {
			customer = customerdao.viewcustomer(customerid);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (CustomerNotFoundException cfe) {
			System.out.println(cfe.getMessage());
		}

		assertTrue(customer == null);
	}


}
