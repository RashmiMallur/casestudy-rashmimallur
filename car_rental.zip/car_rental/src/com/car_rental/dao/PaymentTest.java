package com.car_rental.dao;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.sql.Date;
import java.sql.SQLException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.car_rental.entity.Lease;
import com.car_rental.entity.Payment;

public class PaymentTest {
	private IPaymentDAO paymentdao;

	@Before
	public void setUp() throws Exception {
		paymentdao=new PaymentDAOImpl();
	}

	@After
	public void tearDown() throws Exception {
		paymentdao=null;
	}

	@Test
	public final void testPaymentCreation() {
		int result = 0;
		Payment payment = null;
		Date paymentdate = Date.valueOf("2024-01-03");
		Lease lease = new Lease();
		lease.setLeaseId(3);
		payment = new Payment(lease, paymentdate.toLocalDate(), 10000);
		try {
			result = paymentdao.addPayment(payment);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
			se.printStackTrace();
		}
		assertTrue(result == 1);
	}

}
